# Android System Health Monitor (Kotlin & Jetpack Compose)

Rebuilt natively from Python Tkinter desktop reference main.py.

## Features
- Real-time Battery, RAM, and Storage monitoring using supported Android platform APIs
- Coroutine-driven background data collection with 100% non-blocking Dispatchers.IO
- Swipe-to-Refresh gesture using Material3 PullToRefreshBox
- Live Canvas Charts with dynamic auto-scaling Y-axis and smooth area fill
- 100% Offline with ZERO dangerous runtime permissions
- SELinux CPU measurement diagnostics explaining why /proc/stat is restricted on Android 8+

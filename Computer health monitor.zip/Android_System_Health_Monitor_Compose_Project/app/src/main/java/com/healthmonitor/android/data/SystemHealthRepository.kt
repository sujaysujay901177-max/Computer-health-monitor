package com.healthmonitor.android.data

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.Process
import android.os.StatFs
import android.os.SystemClock
import com.healthmonitor.android.domain.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext

class SystemHealthRepository(private val context: Context) {

    private val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    private var lastCpuTime = Process.getElapsedCpuTime()
    private var lastAppTime = SystemClock.uptimeMillis()

    fun observeSystemHealth(sampleIntervalMs: Long = 500L): Flow<SystemHealthState> = flow {
        var cpuHistory = mutableListOf<Float>()
        var ramHistory = mutableListOf<Float>()
        val maxPoints = (60_000L / sampleIntervalMs).toInt()

        while (true) {
            val state = readCurrentSnapshot(cpuHistory, ramHistory, maxPoints)
            emit(state)
            delay(sampleIntervalMs)
        }
    }.flowOn(Dispatchers.IO) // Non-blocking background worker thread
}
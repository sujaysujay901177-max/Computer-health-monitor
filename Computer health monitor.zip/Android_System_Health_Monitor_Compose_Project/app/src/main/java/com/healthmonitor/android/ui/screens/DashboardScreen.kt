package com.healthmonitor.android.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.material3.pulltorefresh.PullToRefreshDefaults
import androidx.compose.material3.pulltorefresh.rememberPullToRefreshState
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.healthmonitor.android.ui.components.*
import com.healthmonitor.android.ui.theme.*
import com.healthmonitor.android.ui.viewmodel.DashboardViewModel
import com.healthmonitor.android.ui.viewmodel.UiEvent
import kotlinx.coroutines.flow.collectLatest
import java.text.DecimalFormat

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    viewModel: DashboardViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val isRefreshing by viewModel.isRefreshing.collectAsStateWithLifecycle()

    var showCpuDialog by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        viewModel.eventFlow.collectLatest { event ->
            when (event) {
                is UiEvent.ShowToast -> Toast.makeText(context, event.message, Toast.LENGTH_SHORT).show()
                is UiEvent.OpenCpuExplanation -> showCpuDialog = true
                is UiEvent.ReportGenerated -> Toast.makeText(context, "Report ready: ${event.filename}", Toast.LENGTH_LONG).show()
            }
        }
    }

    if (showCpuDialog) {
        CpuLimitationDialog(onDismiss = { showCpuDialog = false })
    }

    Scaffold(
        containerColor = BgDark,
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        if (state == null) {
            Box(modifier = Modifier.fillMaxSize().padding(innerPadding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = AccentBlue)
            }
            return@Scaffold
        }

        val s = state!!
        val df = remember { DecimalFormat("0.0") }

        // Material3 PullToRefreshBox - Swipe-to-Refresh Gesture
        PullToRefreshBox(
            isRefreshing = isRefreshing,
            onRefresh = { viewModel.onSwipeRefresh() },
            modifier = Modifier.fillMaxSize().padding(innerPadding),
            indicator = {
                PullToRefreshDefaults.Indicator(
                    state = rememberPullToRefreshState(),
                    isRefreshing = isRefreshing,
                    containerColor = CardLight,
                    color = AccentBlue,
                    modifier = Modifier.align(Alignment.TopCenter)
                )
            }
        ) {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "ANDROID HEALTH MONITOR",
                            color = AccentBlue,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(CardLight)
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(text = "LIVE DASHBOARD", color = AccentGreen, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // 2x2 Metric Cards Grid
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            MetricCard(
                                title = "CPU USAGE",
                                valueText = "${df.format(s.cpu.appCpuPercent)}%",
                                progressFraction = s.cpu.appCpuPercent / 100f,
                                indicatorColor = AccentBlue,
                                badgeText = "SELinux",
                                modifier = Modifier.weight(1f),
                                onRefresh = { viewModel.refreshNow() },
                                onCopyValue = { clipboardManager.setText(AnnotatedString("${df.format(s.cpu.appCpuPercent)}%")) },
                                onViewDetails = { showCpuDialog = true }
                            )
                            MetricCard(
                                title = "RAM USAGE",
                                valueText = "${df.format(s.memory.usagePercent)}%",
                                progressFraction = s.memory.usagePercent / 100f,
                                indicatorColor = AccentPurple,
                                modifier = Modifier.weight(1f),
                                onRefresh = { viewModel.refreshNow() },
                                onCopyValue = { clipboardManager.setText(AnnotatedString("${df.format(s.memory.usagePercent)}%")) },
                                onViewDetails = { /* show details */ }
                            )
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            MetricCard(
                                title = "STORAGE",
                                valueText = "${df.format(s.storage.usagePercent)}%",
                                progressFraction = s.storage.usagePercent / 100f,
                                indicatorColor = AccentGreen,
                                modifier = Modifier.weight(1f),
                                onRefresh = { viewModel.refreshNow() },
                                onCopyValue = { clipboardManager.setText(AnnotatedString("${df.format(s.storage.usagePercent)}%")) },
                                onViewDetails = { /* show details */ }
                            )
                            MetricCard(
                                title = "BATTERY",
                                valueText = "${s.battery.levelPercent}%",
                                progressFraction = s.battery.levelPercent / 100f,
                                indicatorColor = if (s.battery.levelPercent <= 20 && !s.battery.isPluggedIn) AccentRed else AccentAmber,
                                badgeText = if (s.battery.isPluggedIn) s.battery.powerSource.name else null,
                                modifier = Modifier.weight(1f),
                                onRefresh = { viewModel.refreshNow() },
                                onCopyValue = { clipboardManager.setText(AnnotatedString("${s.battery.levelPercent}%")) },
                                onViewDetails = { /* show details */ }
                            )
                        }
                    }
                }

                item {
                    AlertBanner(
                        alertLevel = s.alertLevel,
                        headline = if (s.activeWarnings.isNotEmpty()) "WARNING: " + s.activeWarnings.joinToString(" | ") else "SYSTEM STATUS: NORMAL",
                        detailText = s.alertDetail
                    )
                }

                item {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        LiveSmoothChart(title = "CPU USAGE HISTORY (APP PROCESS)", history = s.cpuHistory, lineColor = AccentBlue)
                        LiveSmoothChart(title = "RAM USAGE HISTORY (SYSTEM TOTAL)", history = s.ramHistory, lineColor = AccentPurple)
                    }
                }

                item { SystemInfoCard(systemInfo = s.systemInfo) }

                item {
                    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Button(
                            onClick = { viewModel.generateReport() },
                            colors = ButtonDefaults.buttonColors(containerColor = AccentBlue),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("SAVE HEALTH REPORT", color = BgDark, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                        Button(
                            onClick = { viewModel.refreshNow() },
                            colors = ButtonDefaults.buttonColors(containerColor = CardLight),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("REFRESH NOW", color = TextLight, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }
    }
}
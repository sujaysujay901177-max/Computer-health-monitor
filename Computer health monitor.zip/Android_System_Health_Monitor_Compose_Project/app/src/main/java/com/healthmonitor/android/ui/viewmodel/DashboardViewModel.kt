package com.healthmonitor.android.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.healthmonitor.android.data.SystemHealthRepository
import com.healthmonitor.android.domain.model.SystemHealthState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class DashboardViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = SystemHealthRepository(application.applicationContext)

    private val _uiState = MutableStateFlow<SystemHealthState?>(null)
    val uiState: StateFlow<SystemHealthState?> = _uiState.asStateFlow()

    // State for Material3 Swipe-To-Refresh pull gesture
    private val _isRefreshing = MutableStateFlow(false)
    val isRefreshing: StateFlow<Boolean> = _isRefreshing.asStateFlow()

    private val _eventFlow = MutableSharedFlow<UiEvent>()
    val eventFlow: SharedFlow<UiEvent> = _eventFlow.asSharedFlow()

    init {
        startMonitoring()
    }

    private fun startMonitoring() {
        viewModelScope.launch {
            repository.observeSystemHealth(sampleIntervalMs = 500L).collect { state ->
                if (!_isRefreshing.value) {
                    _uiState.value = state
                }
            }
        }
    }

    /**
     * Triggered by Swipe-to-Refresh gesture on the main dashboard.
     * Uses viewModelScope and withContext(Dispatchers.IO) to query
     * BatteryManager, StatFs storage, and ActivityManager memory off the main thread,
     * ensuring 100% UI responsiveness during background collection.
     */
    fun onSwipeRefresh() {
        if (_isRefreshing.value) return

        viewModelScope.launch {
            _isRefreshing.value = true
            try {
                val currentState = _uiState.value
                val refreshed = withContext(Dispatchers.IO) {
                    delay(350) // Smooth gesture finish
                    repository.readCurrentSnapshot(
                        cpuHistory = currentState?.cpuHistory?.toMutableList() ?: mutableListOf(),
                        ramHistory = currentState?.ramHistory?.toMutableList() ?: mutableListOf()
                    )
                }
                _uiState.value = refreshed
                _eventFlow.emit(UiEvent.ShowToast("System metrics updated via swipe"))
            } finally {
                _isRefreshing.value = false
            }
        }
    }

    fun refreshNow() = onSwipeRefresh()
}
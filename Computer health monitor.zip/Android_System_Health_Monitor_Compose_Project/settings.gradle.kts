rootProject.name = "HealthMonitor"
include(":app")
